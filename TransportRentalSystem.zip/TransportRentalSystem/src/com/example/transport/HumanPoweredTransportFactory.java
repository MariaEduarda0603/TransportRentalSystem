package com.example.transport;

public class HumanPoweredTransportFactory implements TransportFactory {
    @Override
    public Transport createScooter() {
        throw new UnsupportedOperationException("Scooter movido a esforço humano não disponível.");
    }

    @Override
    public Transport createBike() {
        return new Bicycle();
    }
}
