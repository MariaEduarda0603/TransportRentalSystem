package com.example.transport;

public class Main {
    public static void main(String[] args) {
        TransportFactory electricFactory = new ElectricTransportFactory();
        
        Transport electricScooter = electricFactory.createScooter();
        electricScooter.ride();  
        
        Transport electricBike = electricFactory.createBike();
        electricBike.ride();  
        
        TransportFactory humanPoweredFactory = new HumanPoweredTransportFactory();
        
        Transport bicycle = humanPoweredFactory.createBike();
        bicycle.ride();  

        Transport rollerSkates = new RollerSkates();
        Transport skateboard = new Skateboard();

        rollerSkates.ride();
        skateboard.ride();


        try {
            Transport scooter = humanPoweredFactory.createScooter();
            scooter.ride();  
        } catch (UnsupportedOperationException e) {
            System.out.println(e.getMessage());
        }
    }
}
