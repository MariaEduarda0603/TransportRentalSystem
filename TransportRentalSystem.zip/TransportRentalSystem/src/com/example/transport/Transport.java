package com.example.transport;

public interface Transport {
    void ride();
}
