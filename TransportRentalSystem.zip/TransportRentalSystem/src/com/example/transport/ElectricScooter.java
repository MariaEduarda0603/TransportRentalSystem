package com.example.transport;

public class ElectricScooter implements Transport {
    @Override
    public void ride() {
        System.out.println("Andando no patinete elétrico.");
    }
}
